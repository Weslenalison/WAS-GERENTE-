let clients = [];
let simulatedCloudBackup = null;

function saveClientsToLocalStorage() {
    localStorage.setItem('was-gerenciador-clients', JSON.stringify(clients));
}

export function getClients() {
    return [...clients]; // Return a copy to prevent direct mutation
}

export function setClients(newClients) {
    clients = newClients;
    saveClientsToLocalStorage();
}

export function addClient(client) {
    clients.push(client);
    saveClientsToLocalStorage();
}

export function updateClient(clientData) {
    const existingClientIndex = clients.findIndex(c => c.id === clientData.id);
    if (existingClientIndex > -1) {
        clients[existingClientIndex] = clientData;
        saveClientsToLocalStorage();
    }
}

export function removeClient(index) {
    clients.splice(index, 1);
    saveClientsToLocalStorage();
}

export function loadClientsFromLocalStorage() {
    const storedClients = localStorage.getItem('was-gerenciador-clients');
    if (storedClients) {
        clients = JSON.parse(storedClients);
    }
}

// Cloud Simulation
export function getSimulatedCloudBackup() {
    return simulatedCloudBackup;
}

export function setSimulatedCloudBackup(data) {
    simulatedCloudBackup = data;
}