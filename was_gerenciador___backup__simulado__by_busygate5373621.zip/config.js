export const correctUsername = "Weslen";
export const correctPassword = "corinthians";
export const recoveryDob = "30/10/2017";

