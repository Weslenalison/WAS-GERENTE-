import * as config from './config.js';
import * as store from './client-store.js';
import * as ui from './ui.js';
import * as utils from './utils.js';

let loginAttempts = 0;

// --- Event Handlers ---

function handleLogin(e) {
    e.preventDefault();
    const username = ui.dom.usernameInput.value;
    const password = ui.dom.passwordInput.value;

    if (username === config.correctUsername && password === config.correctPassword) {
        loginAttempts = 0;
        ui.dom.passwordRecoveryView.style.display = 'none';
        ui.dom.revealedPasswordP.style.display = 'none';
        ui.dom.passwordInput.value = '';
        ui.updateStatus("Login bem-sucedido!");
        ui.showView('manager');
        const clients = store.getClients();
        ui.renderClients(clients);
        ui.checkForExpirations(clients);
    } else {
        loginAttempts++;
        ui.dom.passwordInput.value = '';
        ui.updateStatus(`Usuário ou senha incorretos. Tentativa ${loginAttempts} de 5.`, true);
        if (loginAttempts >= 5) {
            ui.dom.passwordRecoveryView.style.display = 'block';
            ui.dom.loginButton.disabled = true;
        }
    }
}

function handlePasswordRecovery() {
    if (ui.dom.dobInput.value === config.recoveryDob) {
        ui.dom.revealedPasswordP.textContent = `A senha é: ${config.correctPassword}`;
        ui.dom.revealedPasswordP.style.display = 'block';
        ui.updateStatus("Data de nascimento correta. Senha revelada.");
        loginAttempts = 0;
        ui.dom.loginButton.disabled = false;
    } else {
        ui.updateStatus("Data de nascimento incorreta.", true);
        ui.dom.dobInput.value = '';
    }
}

function handleSaveClient(e) {
    e.preventDefault();
    const clientData = {
        id: ui.dom.clientIdInput.value || Date.now().toString(),
        name: ui.dom.clientNameInput.value,
        login: ui.dom.clientLoginInput.value,
        password: ui.dom.clientPasswordInput.value,
        expiry: utils.parseDateTimeFromInput(ui.dom.clientExpiryInput.value),
        urls: ui.dom.clientUrlsInput.value,
        apps: ui.dom.clientAppsInput.value,
        devices: ui.dom.clientDevicesInput.value,
        phone: ui.dom.clientPhoneInput.value,
    };

    const isEditing = !!ui.dom.clientIdInput.value;
    if (isEditing) {
        store.updateClient(clientData);
        ui.updateStatus("Cliente atualizado com sucesso!");
    } else {
        store.addClient(clientData);
        ui.updateStatus("Cliente adicionado com sucesso!");
    }
    
    ui.closeClientForm();
    const clients = store.getClients();
    ui.renderClients(clients);
    ui.checkForExpirations(clients);
}

function handleClientActions(e) {
    const target = e.target;
    const card = target.closest('.client-card');
    if (!card) return;
    
    const index = parseInt(card.dataset.index, 10);
    const clients = store.getClients();
    const client = clients[index];

    if (!client) return;

    if (target.matches('.copy-client-btn')) {
        handleCopyClientInfo(client);
    } else if (target.matches('.edit-client-btn')) {
        ui.openClientForm(client);
    } else if (target.matches('.delete-client-btn')) {
        handleDeleteClient(index, client);
    }
}

async function handleCopyClientInfo(client) {
    const infoToCopy = `Login: ${client.login || 'N/A'}\nSenha: ${client.password || 'N/A'}\nValidade: ${utils.displayDateForUser(client.expiry)}`;
    try {
        await navigator.clipboard.writeText(infoToCopy);
        ui.updateStatus("Informações (Login, Senha, Validade) copiadas para a área de transferência!");
    } catch (err) {
        ui.updateStatus("Erro ao copiar informações.", true);
        console.error('Failed to copy: ', err);
    }
}

function handleDeleteClient(index, client) {
    if (confirm(`Tem certeza que deseja excluir o cliente "${client.name || client.login}"?`)) {
        store.removeClient(index);
        ui.updateStatus("Cliente excluído.");
        const clients = store.getClients();
        ui.renderClients(clients);
        ui.checkForExpirations(clients);
    }
}

async function handlePasteClientInfo() {
    try {
        const text = await navigator.clipboard.readText();
        const loginMatch = text.match(/Login:\s*(.*)/i);
        const senhaMatch = text.match(/Senha:\s*(.*)/i);
        const validadeMatch = text.match(/Validade:\s*(\d{2}\/\d{2}\/\d{4}(?:\s+\d{2}:\d{2})?)/i);

        if (loginMatch && loginMatch[1]) ui.dom.clientLoginInput.value = loginMatch[1].trim();
        if (senhaMatch && senhaMatch[1]) ui.dom.clientPasswordInput.value = senhaMatch[1].trim();
        if (validadeMatch && validadeMatch[1]) {
            const parts = validadeMatch[1].trim().split(' ');
            const dateParts = parts[0].split('/');
            const timeParts = parts[1] ? parts[1].split(':') : ['00', '00'];
            const formattedDate = `${dateParts[2]}-${dateParts[1]}-${dateParts[0]}`;
            const formattedTime = `${timeParts[0]}:${timeParts[1]}`;
            ui.dom.clientExpiryInput.value = `${formattedDate}T${formattedTime}`;
        }
        ui.updateStatus("Informações coladas do clipboard. Verifique os campos.");
    } catch (err) {
        ui.updateStatus("Falha ao ler da área de transferência ou formato inválido.", true);
        console.error('Failed to read clipboard contents: ', err);
    }
}

function handleNotificationClick(e) {
    if (e.target.classList.contains('notification-button')) {
        const clientId = e.target.dataset.clientId;
        const type = e.target.dataset.type;
        const client = store.getClients().find(c => c.id === clientId);

        if (client) {
            const phone = client.phone.replace(/\D/g, '');
            let message = '';
            if (type === 'soon') {
                message = "ATENÇÃO!!! Seu IPTV vence em dois dias!";
            } else if (type === 'today') {
                message = "ATENÇÃO!!! Seu IPTV vence hoje!";
            }

            if (message && phone) {
                const finalPhone = phone.length > 11 ? phone : `55${phone}`;
                const encodedMessage = encodeURIComponent(message);
                const whatsappUrl = `https://wa.me/${finalPhone}?text=${encodedMessage}`;
                window.open(whatsappUrl, '_blank');
                ui.updateStatus(`Abrindo WhatsApp para notificar ${client.name}.`);
            } else {
                ui.updateStatus('Número de telefone ou tipo de mensagem inválido.', true);
            }
        }
    }
}

function handleBackup() {
    const clients = store.getClients();
    if (clients.length === 0) {
        ui.updateStatus("Nenhum cliente para salvar.", true);
        return;
    }
    ui.updateStatus("Salvando dados na nuvem (simulado)...");
    setTimeout(() => {
        store.setSimulatedCloudBackup(JSON.stringify(clients));
        ui.updateStatus("Dados dos clientes salvos na nuvem (simulado)!");
    }, 1000);
}

function handleRestore() {
    ui.updateStatus("Carregando dados da nuvem (simulado)...");
    setTimeout(() => {
        const backup = store.getSimulatedCloudBackup();
        if (backup) {
            const restoredClientsData = JSON.parse(backup);
            if (confirm(`Encontrado backup com ${restoredClientsData.length} clientes. Deseja substituir os clientes atuais?`)) {
                store.setClients(restoredClientsData);
                const newClients = store.getClients();
                ui.renderClients(newClients);
                ui.checkForExpirations(newClients);
                ui.updateStatus("Dados dos clientes restaurados da nuvem (simulado)!");
            } else {
                ui.updateStatus("Restauração cancelada.");
            }
        } else {
            ui.updateStatus("Nenhum backup encontrado na nuvem (simulado).", true);
        }
    }, 1000);
}

function handleSignOut() {
    if (confirm("Tem certeza que deseja sair? Seus dados de clientes permanecerão salvos no dispositivo.")) {
        store.setSimulatedCloudBackup(null);
        loginAttempts = 0;
        ui.resetLoginForm(config.correctUsername);
        ui.closeClientForm();
        ui.updateStatus("Você saiu. Seus dados foram mantidos localmente.");
        ui.showView('login');
    }
}

// --- App Initialization ---
function init() {
    // Event Listeners
    ui.dom.loginForm.addEventListener('submit', handleLogin);
    ui.dom.recoverPasswordButton.addEventListener('click', handlePasswordRecovery);
    ui.dom.showAddClientFormButton.addEventListener('click', () => ui.openClientForm());
    ui.dom.cancelClientFormButton.addEventListener('click', ui.closeClientForm);
    ui.dom.clientForm.addEventListener('submit', handleSaveClient);
    ui.dom.pasteClientInfoButton.addEventListener('click', handlePasteClientInfo);
    ui.dom.clientsContainer.addEventListener('click', handleClientActions);
    ui.dom.notificationsArea.addEventListener('click', handleNotificationClick);
    ui.dom.backupButton.addEventListener('click', handleBackup);
    ui.dom.restoreButton.addEventListener('click', handleRestore);
    ui.dom.signOutButton.addEventListener('click', handleSignOut);

    // Initial state
    store.loadClientsFromLocalStorage();
    ui.showView('login');
    ui.dom.usernameInput.value = config.correctUsername;
    ui.updateStatus("Bem-vindo ao WAS Gerenciador. Faça o login para continuar.");
}

document.addEventListener('DOMContentLoaded', init);