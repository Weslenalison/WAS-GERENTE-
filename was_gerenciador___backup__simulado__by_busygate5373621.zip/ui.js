import { displayDateForUser, formatDateTimeForInput } from './utils.js';

// Centralized DOM Elements
export const dom = {
    // App
    appContainer: document.getElementById('app-container'),
    statusMessageP: document.getElementById('statusMessage'),

    // Login View
    loginView: document.getElementById('login-view'),
    loginForm: document.getElementById('login-form'),
    usernameInput: document.getElementById('username'),
    passwordInput: document.getElementById('password'),
    loginButton: document.getElementById('loginButton'),

    // Password Recovery
    passwordRecoveryView: document.getElementById('password-recovery-view'),
    dobInput: document.getElementById('dob'),
    recoverPasswordButton: document.getElementById('recoverPasswordButton'),
    revealedPasswordP: document.getElementById('revealedPassword'),
    
    // Client Manager View
    clientManagerView: document.getElementById('client-manager-view'),
    userInfoP: document.getElementById('userInfo'),
    showAddClientFormButton: document.getElementById('showAddClientFormButton'),
    signOutButton: document.getElementById('signOutButton'),
    notificationsArea: document.getElementById('notifications-area'),
    clientsContainer: document.getElementById('clients-container'),

    // Client Form
    clientFormSection: document.getElementById('client-form-section'),
    clientForm: document.getElementById('client-form'),
    formTitle: document.getElementById('formTitle'),
    clientIdInput: document.getElementById('clientId'),
    clientNameInput: document.getElementById('clientName'),
    clientLoginInput: document.getElementById('clientLogin'),
    clientPasswordInput: document.getElementById('clientPassword'),
    clientExpiryInput: document.getElementById('clientExpiry'),
    clientUrlsInput: document.getElementById('clientUrls'),
    clientAppsInput: document.getElementById('clientApps'),
    clientDevicesInput: document.getElementById('clientDevices'),
    clientPhoneInput: document.getElementById('clientPhone'),
    saveClientButton: document.getElementById('saveClientButton'),
    pasteClientInfoButton: document.getElementById('pasteClientInfoButton'),
    cancelClientFormButton: document.getElementById('cancelClientFormButton'),
    
    // Cloud
    backupButton: document.getElementById('backupButton'),
    restoreButton: document.getElementById('restoreButton'),
};

export function updateStatus(message, isError = false) {
    dom.statusMessageP.textContent = message;
    dom.statusMessageP.style.color = isError ? '#c0392b' : '#2c3e50';
    setTimeout(() => {
        if (dom.statusMessageP.textContent === message) {
            dom.statusMessageP.textContent = "";
        }
    }, 5000);
}

export function showView(viewToShow) {
    dom.loginView.style.display = 'none';
    dom.clientManagerView.style.display = 'none';
    dom.clientFormSection.style.display = 'none'; 

    if (viewToShow === 'login') {
        dom.loginView.style.display = 'flex';
        dom.appContainer.style.backgroundColor = '#E0F7FA'; 
    }
    if (viewToShow === 'manager') {
        dom.clientManagerView.style.display = 'flex';
        dom.appContainer.style.backgroundColor = 'orange'; 
    }
}

function buildListHTML(title, itemsText) {
    if (!itemsText || itemsText.trim() === '') return '';
    const items = itemsText.split('\n').filter(item => item.trim() !== '');
    if (items.length === 0) return '';

    let listItems = items.map(item => `<li>${item.trim()}</li>`).join('');
    return `
        <div class="client-detail-list">
            <p><strong>${title}:</strong></p>
            <ul>${listItems}</ul>
        </div>
    `;
}

export function renderClients(clients) {
    dom.clientsContainer.innerHTML = '';
    if (clients.length === 0) {
        dom.clientsContainer.innerHTML = '<p>Nenhum cliente adicionado ainda.</p>';
        return;
    }
    clients.forEach((client, index) => {
        const card = document.createElement('div');
        card.classList.add('client-card');
        card.dataset.index = index; 
        card.innerHTML = `
            <h5>${client.name || 'Cliente sem nome'}</h5>
            <p><strong>Login:</strong> ${client.login || 'N/A'}</p>
            <p><strong>Senha:</strong> ${client.password || 'N/A'}</p>
            <p><strong>Validade:</strong> ${displayDateForUser(client.expiry)}</p>
            ${client.phone ? `<p><strong>Telefone:</strong> ${client.phone}</p>` : ''}
            ${buildListHTML('URL(s)', client.urls)}
            ${buildListHTML('Aplicativos', client.apps)}
            ${buildListHTML('Dispositivos', client.devices)}
            <div class="client-actions">
                <button class="copy-client-btn secondary-action-btn">Copiar Info</button>
                <button class="edit-client-btn secondary-action-btn">Editar</button>
                <button class="delete-client-btn delete-btn">Excluir</button>
            </div>
        `;
        dom.clientsContainer.appendChild(card);
    });
}


export function checkForExpirations(clients) {
    dom.notificationsArea.innerHTML = '';
    const clientsToNotify = [];
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    clients.forEach(client => {
        if (client.phone && client.expiry) {
            try {
                const expiryDate = new Date(client.expiry);
                expiryDate.setHours(0, 0, 0, 0);

                const diffTime = expiryDate.getTime() - today.getTime();
                const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));

                if (diffDays === 2) {
                    clientsToNotify.push({ client, type: 'soon' });
                } else if (diffDays === 0) {
                    clientsToNotify.push({ client, type: 'today' });
                }
            } catch (e) {
                console.error(`Invalid date for client ${client.name}: ${client.expiry}`);
            }
        }
    });

    if (clientsToNotify.length > 0) {
        let content = '<h3>Lembretes de Vencimento</h3>';
        clientsToNotify.forEach(item => {
            const { client, type } = item;
            const message = type === 'soon' ? `Vence em 2 dias` : `Vence hoje`;
            content += `<button class="notification-button" data-client-id="${client.id}" data-type="${type}">
                Notificar ${client.name} (${message})
            </button>`;
        });
        dom.notificationsArea.innerHTML = content;
        dom.notificationsArea.style.display = 'block';
    } else {
        dom.notificationsArea.style.display = 'none';
    }
}

export function openClientForm(clientToEdit = null) {
    dom.clientForm.reset();
    if (clientToEdit) {
        dom.formTitle.textContent = "Editar Cliente";
        dom.clientIdInput.value = clientToEdit.id;
        dom.clientNameInput.value = clientToEdit.name || '';
        dom.clientLoginInput.value = clientToEdit.login || '';
        dom.clientPasswordInput.value = clientToEdit.password || '';
        dom.clientExpiryInput.value = formatDateTimeForInput(clientToEdit.expiry);
        dom.clientUrlsInput.value = clientToEdit.urls || '';
        dom.clientAppsInput.value = clientToEdit.apps || '';
        dom.clientDevicesInput.value = clientToEdit.devices || '';
        dom.clientPhoneInput.value = clientToEdit.phone || '';
    } else {
        dom.formTitle.textContent = "Adicionar Novo Cliente";
        dom.clientIdInput.value = '';
    }
    dom.clientFormSection.style.display = 'block';
    dom.showAddClientFormButton.style.display = 'none';
}

export function closeClientForm() {
    dom.clientFormSection.style.display = 'none';
    dom.showAddClientFormButton.style.display = 'block';
    dom.clientForm.reset();
}

export function resetLoginForm(username) {
    dom.usernameInput.value = username;
    dom.passwordInput.value = "";
    dom.dobInput.value = "";
    dom.passwordRecoveryView.style.display = 'none';
    dom.revealedPasswordP.style.display = 'none';
    dom.loginButton.disabled = false;
}