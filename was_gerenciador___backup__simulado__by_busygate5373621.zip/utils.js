export function formatDateTimeForInput(isoString) {
    if (!isoString) return '';
    // ISO string from Date.toISOString() is like "2024-07-28T10:30:00.000Z"
    // datetime-local input needs "YYYY-MM-DDTHH:MM"
    return isoString.substring(0, 16);
}

export function parseDateTimeFromInput(inputString) {
    if (!inputString) return null;
    return new Date(inputString).toISOString();
}

export function displayDateForUser(isoString) {
    if (!isoString) return 'N/A';
    try {
        const date = new Date(isoString);
        return date.toLocaleString('pt-BR', {
            day: '2-digit', month: '2-digit', year: 'numeric',
            hour: '2-digit', minute: '2-digit'
        });
    } catch (e) {
        return 'Data inválida';
    }
}